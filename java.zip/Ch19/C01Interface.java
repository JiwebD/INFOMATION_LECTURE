package Ch19;

interface Shape {
	abstract double area();
	abstract double perimeter();
}

class Circle01 implements Shape {
	private double radius;

	public Circle01(double radius) {
		this.radius = radius;
	}

	@Override
	public double area() {
		return Math.PI * radius * radius;
	}

	@Override
	public double perimeter() {
		return 2 * Math.PI * radius;
	}
	
}
public class C01Interface {
	public static void main(String[] args) {
		Circle01 newCir = new Circle01(3.0);
		System.out.println(newCir.area());
		System.out.println(newCir.perimeter());
	}

}
