package Ch19;
interface Eatable {
	void eat();
}

interface Sleepable {
	void sleep();
}

class Dog implements Eatable, Sleepable {

	@Override
	public void sleep() {
		System.out.println("개가 잠을 잡니다.");
		
	}

	@Override
	public void eat() {
		System.out.println("개가 먹습니다.");
		
	}
}
public class C02Mulinterface2 {
	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.sleep();
		dog.eat();
		
		Eatable obj = new Dog();
		
		obj.eat();
//		obj.sleep();
		
	}

}
