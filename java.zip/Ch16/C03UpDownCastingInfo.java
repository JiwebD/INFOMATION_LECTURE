package Ch16;
class Exam{
	int num1;

	
//	public void printNum1 () {
//		System.out.println(num1);
//	}
	
	// =========================================
	// 오버라이딩용 메서드
	// =========================================
	public void write() {
		System.out.println("부모에서 쓰는 중");
	}

	
}

class Example extends Exam {
	int num2;
	
//	public void printNum2 () {
//		System.out.println(num2);
//	}
	
	// =========================================
	// 오버라이딩용 메서드
	// =========================================
	public void write() {
		System.out.println("자식에서 쓰는 중");
	}
	
}

class ExampleTest extends Exam {
	
}




public class C03UpDownCastingInfo {
	public static void main(String[] args) {
		
		// NoCasting 상태 == No (안해) Casting(형을 변환하는 과정) 
		Exam obj = new Exam();
		obj.num1 = 20;
		obj.printNum1();
//		obj.num2 = 30;			// X
//		obj.printNum2();		// X
		
		
		
		Example obj2 = new Example();
		obj2.num1 = 100;
		obj2.printNum1();
		obj2.num2 = 200;		
		obj2.printNum2();
		
		// UpCasting 상태 == Up (위로) Casting (형을 변환하는 과정)
		// 자식 객체(DOWN)를 부모 타입(UP)으로 형을 변환하는 과정
		Exam obj3 = new Example();
		obj3.num1 = 120;
		obj3.printNum1();
//		obj3.num2 = 220;		// X	범위 초과
//		obj3.printNum2();		// X	범위 초과
		
		// ??? : 그러면 부모 객체를 자식이 받아줄 수 있나요?
//		Example obj4 = new Exam(); 	// Type mismatch: cannot convert from Exam to Example
									// 자료형가 맞지 않음(매치 X) : Exam을 Example 자료형으로 변환이 안됨 XXXX
		
		
		// DownCasting 상태 == Down(아래로) Casting (형을 변환하는 과정)
		// 부모 타입(UP)을 자식 객체(DOWN)으로 형을 변환하는 과정
		// 조건 : 업캐스팅이 선행
		
		Exam obj5 = new Example();			// UpCasting
		// obj5를 활용해서 접근할 수 있는 변수 / 메서드 : num1, printNum1()
		
		// obj5는 부모 객체를 참조하는 obj와 결과론적으로는 활용할 수 있는 변수 / 메서드는 같다 ==> num1, printNum1()
		// 하지만, obj5와 obj가 참조하는 객체의 종류가 다름.
		// obj5 : 자식 클래스 객체를 참조 중
		// obj  : 부모 클래스 객체를 참조 중
		
		// obj5는 현재로써는 num1과 printNum1() 밖에 참조할 수 없지만,
		// DownCasting으로 obj5가 참조하고 있는 객체와 형태(자료형)를 맞춰준다면
		// 얼마든지 num2와 printNum2()까지 사용할 수 있다는 이야기.. ==> DownCasting
		
//		Example down = obj5;		// obj5의 주소값(자식 객체의 주소값)을 down 참조변수에게 전달
									// 현재, Example 타입 = Exam 타입 
									// 이므로, 양 변(좌항, 우항)의 자료형이 일치 X
			
//		양변의 자료형을 일치시켜주기 위해서 강제 형변환을 진행 == DownCasting
		Example down = (Example) obj5;
		down.num1 = 100;
		down.printNum1();
		down.num2 = 200;
		down.printNum2();
		
		//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		// 근데 문제가 발생함.
		//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		
		// 서로 관련이 없는 형태로 다운캐스팅을 하는 일이 빈번히 생기기 시작
		Exam obj6 = new Example();
		
//		ExampleTest down2 = (ExampleTest) obj6;			// Error
		
		
		// instanceof 키워드 등장 : 클래스들 간의 관계성 여부를 판단해주는 키워드
		
		// obj6가 참조하는 객체(자식 클래스 객체 == new Example())가 Example 클래스의 인스턴스라면 True 반환
//																			    아니라면 False 반환
		
		if (obj6 instanceof Example) {
			// obj6가 참조하고 있는 객체는 Example의 인스턴스(Example로 부터 파생되었다)임.
			Example down3 = (Example) obj6;
			
		} 
		
		
		
		// ===================================== 예외 ============================================
		// 오버라이딩 <== 예외
		
		// 부모클래스 참조변수 = new 자식클래스();			==> UpCasting
		Exam test = new Example();
		
		test.num1 =100;
		test.write();
		
		Example test2 = new Example();
		test2.write();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
