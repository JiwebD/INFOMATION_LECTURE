package Ch16;


// Course 클래스
// 속성 : 수학 수업 정원(Ex. 50명, 100명 등), 과학 수업 정원
// Math
// Science

class Course {
	static int mathSeats = 30;
	static int scienceSeats = 30;
	
	public void registerForCourse () {
		
	}
	
}

class Math01 extends Course {
	@Override
	public void registerForCourse () {
		// 수학 수업 잔여석이 있다면
		if(mathSeats > 0) {
			mathSeats--;
			System.out.println("수학 수업에 수강신청을 했습니다.");
			
		} else {
			System.out.println("수학 수업 정원 초과");
		}
	}
	
}

class Science01 extends Course {
	@Override
	public void registerForCourse () {
		// 과학 수업 잔여석이 있다면
		if(scienceSeats > 0) {
			scienceSeats--;
			System.out.println("과학 수업에 수강신청을 했습니다.");
			
		} else {
			System.out.println("과학 수업 정원 초과");
		}
	}
	
}
class Student01 {
	public static void registerForCourse(Course course) {
//		if (course instanceof Math01) {
//			// 조건 : 수학 객체를 받는다면
//			// 1.문구를 출력 ("수학 수업에 수강신청을 했습니다")
//			// 2.수학 수업 정원 - 1
//			System.out.println("수학 수업에 수강신청을 했습니다.");
//			Course.mathSeats --;
//			
//		} else if (course instanceof Science01) {
//			// 조건 : 과학 객체를 받는다면
//			// 1.문구를 출력 ("과학 수업에 수강신청을 했습니다")
//			// 2.과학 수업 정원 - 1
//			System.out.println("과학 수업에 수강신청을 했습니다.");
//			Course.scienceSeats --;
//		}
		
		course.registerForCourse();
	}
	
	public static void showSeatsInfo() {
		System.out.println("======================================================");
		System.out.println("[SYSTEM] : 수업 잔여석 현황");
		System.out.println("수학 수업 남은 정원 : " + Course.mathSeats);
		System.out.println("과학 수업 남은 정원 : " + Course.scienceSeats);
		System.out.println("======================================================");
		
	}
	
}

public class C05PracAcademy {
	
	public static void main(String[] args) {
		
		Math01 mathClass = new Math01();
		Science01 scienceClass = new Science01();		
		
		
		Student01.registerForCourse(mathClass);		// 수학 수업에 수강신청을 했습니다. 
													// 수학 수업 정원 - 1;	
		
		Student01.registerForCourse(scienceClass);	// 과학 수업에 수강신청을 했습니다.
													// 과학 수업 정원 - 1;
		
		Student01.showSeatsInfo();					// 남은 수업 정원 정보를 출력
													// 수학 수업 정원 : 29명
													// 과학 수업 정원 : 29명
		
	}

}
