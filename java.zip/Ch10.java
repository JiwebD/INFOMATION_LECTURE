import java.util.Scanner;

public class Ch10 {
	public static void main(String[] args) {
		

		// 중첩 while문 
	    //문제
		//구구단 2단 출력
		
//		int dan = 2;
//		int i =1;
//		while (i <= 9) {
//			System.out.printf("%d x %d = %d\n", dan, i, dan*i);
//			i++;
//		}

		//문제
		//구구단 2단 출력(역순출력)
//		int dan = 2;
//		int i =9;
//		while (i >= 1) {
//			System.out.printf("%d x %d = %d\n", dan, i, dan*i);
//			i--;
//		}

		//문제
		//구구단 N단 출력(입력받기)
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("단을 입력해주세요 >>>");
//		int dan = sc.nextInt();		// 3
//		
//		int i = 1;
//		while(i <= 9) {
//			System.out.printf("%d x %d = %d\n", dan, i, dan * i);
//			i++;
//		}
		
		
		//문제
		//구구단 N단 출력(입력받기,역순출력)
		
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("단을 입력해주세요 >>>");
//		int dan = sc.nextInt();		// 3
//		
//		int i = 9;
//		while(i >= 1) {
//			System.out.printf("%d x %d = %d\n", dan, i, dan * i);
//			i--;
//		}

		//전체 구구단(2단-9단) 출력하기
//		
//		int dan = 2;
//		while (dan <= 9) {
//			int i = 1;
//			while(i <= 9) {
//				System.out.printf("%d x %d = %d\n", dan, i, dan * i);
//				i++;
//			}
//			System.out.println();
//			dan++;
//		}
//	
//		
		
		//N부터 9단까지 전체 출력
//		Scanner sc = new Scanner(System.in);
//		
//		int dan = sc.nextInt();
//		while (dan <= 9) {
//			int i = 1;
//			while(i <= 9) {
//				System.out.printf("%d x %d = %d\n", dan, i, dan * i);
//				i++;
//			}
//			System.out.println();
//			dan++;
//		}
		
		//전체 구구단(2단-9단) 출력하기 (단만 역순출력)
		
//		int dan = 9;
//		while (dan >= 2) {
//			int i = 1;
//			while(i <= 9) {
//				System.out.printf("%d x %d = %d\n", dan, i, dan * i);
//				i++;
//			}
//			System.out.println();
//			dan--;
//		}
	

		//전체 구구단(2단-9단) 출력하기 (전체 역순출력)
//		int dan = 9;
//		while (dan >= 2) {
//			int i = 9;
//			while(i >= 1) {
//				System.out.printf("%d x %d = %d\n", dan, i, dan * i);
//				i--;
//			}
//			System.out.println();
//			dan--;
//		}
		

		
		// 1
		// *****
		// *****
		// *****
		// *****

		
//		int i = 1;
//		while (i <= 4) {
//			int j =1;
//			while(j <= 5) {
//				System.out.print("*");
//				j++;
//			}
//			System.out.println();
//			i++;
//		}

		// 높이 : n
		// *****
		// *****
		// *****
		// *****
//		Scanner sc = new Scanner(System.in);
//		System.out.println("높이를 입력해주세요 >>> ");
//		int height = sc.nextInt();		// 5
//		int i = 1;
//		while (i <= height	 ) {		// 5번 반복
//			
//			// 별 5개를 찍고
//			int j = 1;
//			while(j <= 5) {
//				System.out.print("*");
//				j++;
//			}
//			
//			
//			// 엔터 치기
//			System.out.println();
//			i++;
//		}
		

		// 2
		// *
		// **
		// ***
		// ****
//		
//		int i = 1;
//		while (i <= 4) {
//			int j = 1;
//			while (j <= i) {
//				System.out.print("*");
//				j++;
//			}
//			// 엔터(개행
//			System.out.println();
//			i++;
//		}
//		
//		
//		
//		
//		int i = 1;
//		while (i <= 4) {
//			
//			if (i == 1) {
//				int j = 1;
//				while (j <= 1) {
//					System.out.print("*");
//					j++;
//				}
//				
//			} else if (i == 2) {
//				int j = 1;
//				while (j <= 2) {
//					System.out.print("*");
//					j++;
//				}
//			} else if (i == 3) {
//				int j = 1;
//				while (j <= 3) {
//					System.out.print("*");
//					j++;
//				}
//			} else {
//				int j = 1;
//				while (j <= 4) {
//					System.out.print("*");
//					j++;
//				}
//			}
//			
//			
//			System.out.println();
//			i++;
//		}
//		
		
		
		
		

		// 높이 : 4
		// *
		// **
		// ***
		// ****
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("높이를 해주시면 그 높이에 맞는 직각삼각형을 만들어 드릴게요 >>> ");
//		int height = sc.nextInt();
//		
//		int i = 1;
//		while (i <= height) {
//			int j = 1;
//			while (j <= i) {
//				System.out.print("*");
//				j++;
//			}
//			
//			System.out.println();
//			i++;
//		}
//	
		
		
		
		//3
		//****
		//***
		//**
		//*
		
//		int i = 1;
//		while (i <=4 ) {
//			
//			int j = 1;
//			while (j <= 5-i) {
//				System.out.print("*");
//				j++;
//			}
//			
//			System.out.println();
//			i++;
//		}
//		
		
			
		//높이 : 4
		//****
		//***
		//**
		//*
//		
//		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("높이를 해주시면 그 높이에 맞는 직각삼각형을 만들어 드릴게요 >>> ");
//		int height = sc.nextInt();
//		
//		int i = 1;
//		while (i <= height ) {
//			
//			int j = 1;
//			while (j <= height + 1 - i) {
//				System.out.print("*");
//				j++;
//			}
//			
//			System.out.println();
//			i++;
//		}
		
			
		//4
		//   *
		//  ***
		// *****
		//*******
		
		int i = 1;
		while(i <=4 ) {
			// i값      1 2 3 4
			// 공백 반복  3 2	1 0
			int j = 1;
			while(j <= 4- i) {
				System.out.print(" ");
				j++;
			}
			// 별 반복 	1 3 5 7
			int k = 1;
			while(k <= 2 * i -1) {
				System.out.print("*");
				k++;
			}
			System.out.println();
			i++;
		}
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
