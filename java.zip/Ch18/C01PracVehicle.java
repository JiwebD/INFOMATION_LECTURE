package Ch18;

import javax.swing.plaf.synth.SynthOptionPaneUI;

// 부모 클래스 Vehicle
// 정보 : 연료량(fuel)

// 자식 클래스 Car, Motorcycle

abstract class Vehicle {
	protected int fuel = 100;
	
	abstract void drive();
	// 1. 연료 확인 추상 메서드 
//	abstract void showFuel();
	
	// 2. 연료 확인 일반 메서드
	void showFuel() {
		System.out.printf("%s 연료량 : %d\n", this.getClass().getSimpleName(), this.fuel);
	}
	
}


class Car extends Vehicle {
	@Override
	void drive() {
		if(fuel > 5) {
			fuel -= 5;
			System.out.println("차를 운전합니다.");
		}  else {
			System.out.println("연료가 부족합니다. 차를 운전할 수 없습니다.");
		}
		
	}
	
//	@Override
//	void showFuel() {
//		System.out.println("자동차 연료량 출력 : " + fuel);
//		
//	}
//	
}

class Motorcycle extends Vehicle {
	@Override
	void drive() {
		if(fuel > 5) {
			fuel -= 5;
			System.out.println("오토바이를 운전합니다.");
		}  else {
			System.out.println("연료가 부족합니다. 오토바이를 운전할 수 없습니다.");
		}
	}
//	@Override
//	void showFuel() {
//		System.out.println("오토바이 연료량 출력 : " + fuel);
//	}
}


public class C01PracVehicle {
	public static void ShowInfo(Vehicle obj) {
		obj.showFuel();
	}
	
	public static void main(String[] args) {
		Car car = new Car();							
		Motorcycle motorcycle = new Motorcycle(); 	
		
		
		car.drive();				// 차를 운전합니다.
									// 연료량 5감소
		motorcycle.drive();			// 오토바이를 운전합니다.
									// 연료량 5 감소

		ShowInfo(car);					// 자동차 연료량 출력 : 95
		ShowInfo(motorcycle);			// 오토바이 연료량 출력 : 95
	}

}
