package Ch17;

public class C04MainArgsTestExample {
	public static void main(String[] args) {
		
		
		System.out.println("배열 길이 : " + args.length);
		
		
		// forEach(개선된 for문)
		for (String str : args) {
			System.out.println(str);
		}
	}

}
