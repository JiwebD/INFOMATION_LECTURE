package Ch17;

import java.util.Scanner;

public class C02PracStudent {
	public static void main(String[] args) {
		
		// 문제
		// 5명의 학생의 국어 점수를 입력받아 출력을 해보자!!!
		// [결과값]
		// 1번째 학생의 국어 점수를 입력해주세요 >>> 90
		// 2번째 학생의 국어 점수를 입력해주세요 >>> 100
		// 3번째 학생의 국어 점수를 입력해주세요 >>> 86
		// 4번째 학생의 국어 점수를 입력해주세요 >>> 74
		// 5번째 학생의 국어 점수를 입력해주세요 >>> 95
		//------------------------------------------------
		// 1번째 학생 국어 점수 : 90
		// 2번째 학생 국어 점수 : 100
		// 3번째 학생 국어 점수 : 86
		// 4번째 학생 국어 점수 : 74
		// 5번째 학생 국어 점수 : 95
		//
		
		int[] score = new int[5];
		
		Scanner sc = new Scanner(System.in);
//		System.out.println("1번째 학생의 국어 점수를 입력해주세요 >>>");
//		score[0] = sc.nextInt();
//		
//		System.out.println("2번째 학생의 국어 점수를 입력해주세요 >>>");
//		score[1] = sc.nextInt();
//		
//		System.out.println("3번째 학생의 국어 점수를 입력해주세요 >>>");
//		score[2] = sc.nextInt();
//		
//		System.out.println("4번째 학생의 국어 점수를 입력해주세요 >>>");
//		score[3] = sc.nextInt();
//		
//		System.out.println("5번째 학생의 국어 점수를 입력해주세요 >>>");
//		score[4] = sc.nextInt();
		
		// 어? 여기서 형식이 반복되고 친절문구의 1,2,3,4,5번째의 숫자와 score[] 대괄호안의 숫자가 차례로 증가함.
		// ==> 반복문을 사용하면 되겠다.
		
		for(int i = 0; i < score.length; i++) {
			System.out.println( (i+1) +"번째 학생의 국어 점수를 입력해주세요 >>>");
			score[i] = sc.nextInt();
		}
		
		
		// 학생 점수 출력
		for (int i = 0; i <score.length; i++) {
			System.out.println((i+1) + "번째 학생 국어 점수 : " + score[i]);
		}
		
		
		
	}

}
