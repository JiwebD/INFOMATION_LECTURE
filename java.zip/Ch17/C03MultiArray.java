package Ch17;

public class C03MultiArray {
	public static void main(String[] args) {
		
		// 이차원배열 [행] [열]
		int[][] arr = new int[2][4];
		
		
		arr[0][0] = 1;
		arr[0][1] = 2;
		arr[0][2] = 3;
		arr[0][3] = 4;
		
		arr[1][0] = 11;
		arr[1][1] = 22;
		arr[1][2] = 33;
		arr[1][3] = 44;
		
		
		System.out.println("행 개수 : " + arr.length);
		System.out.println("0행 열 개수 : " + arr[0].length);
		System.out.println("1행 열 개수 : " + arr[1].length);
		
		
		// 출력
		for (int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
				System.out.println(arr[i][j] + " ");
			}
			System.out.println();
		}
	

	}

}
