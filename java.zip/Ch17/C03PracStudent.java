package Ch17;

import java.util.Scanner;

public class C03PracStudent {
	public static void main(String[] args) {
		// 문제
		// 5명의 학생의 국/영/수 점수를 입력받아 출력을 해보자!!
		
		// [출력예]
//		// 1번쨰 학생 점수입력(국/영/수 순서) : 100 70 60
//		// 2번쨰 학생 점수입력(국/영/수 순서) : 99 98 66
//		// 3번쨰 학생 점수입력(국/영/수 순서) : 99 88 77
//		// 4번쨰 학생 점수입력(국/영/수 순서) : 100 55 66
//		// 5번쨰 학생 점수입력(국/영/수 순서) : 55 66 77
		
		Scanner sc = new Scanner(System.in);
		
		int[][] std_score = new int[5][3];
		
		for(int i = 0; i < std_score.length; i++) {
			System.out.print( (i+1) + "번째 학생 점수입력(국/영/수 순서) : ");
			for(int j = 0; j < std_score[i].length; j++) {
				std_score[i][j] = sc.nextInt();
			}
		}
		
		//각행의 합 과 전체 합
		// 각행의 평균 전체 평균을 출력하세요
		
		// [출력예]
//		// 1번째 학생 총점 : ? 평균 ?
//		// 2번째 학생 총점 : ? 평균 ?
//		// 3번째 학생 총점 : ? 평균 ?
//		// 4번째 학생 총점 : ? 평균 ?
//		// 5번째 학생 총점 : ? 평균 ?
		
		// 누적합을 저장해줄 변수 선언
		int sum = 0;
		double avg = 0;
		
		for(int i = 0; i < std_score.length; i++	 ) {
			// 이전 학생의 총점을 가지고 있는 sum을 초기화
			sum = 0;
			for(int j = 0; j < std_score[i].length; j++) {
				// 각 학생의 국/영/수 점수를 sum에 더함.
				sum += std_score[i][j];
			}
			// 첫번째 학생의 국영수 평균을 구함.
			avg = (double) sum / 3;
			System.out.println( (i+1) + "번째 학생 총점 : " + sum + " 평균 : " + avg);
			
		}
		
//	
//		// 국어 총점 : ? 국어 평균 : ?
//		// 영어 총점 : ? 영어 평균 : ?
//		// 수학 총점 : ? 수학 평균 : ?
		
		int ksum = 0;
		int esum = 0;
		int msum = 0;
		
		double kavg, eavg, mavg;

		for(int i = 0; i < std_score.length; i++	 ) {
			// 각 학생의 국어/영어/수학 성적을 각각 ksum,esum,msum에 누적.
			// ==> 각 과목의 누적합
			ksum += std_score[i][0];
			esum += std_score[i][1];
			msum += std_score[i][2];
		}
		
		// 각 과목의 평균
		kavg = (double) ksum / 5;
		eavg = (double) esum / 5;
		mavg = (double) msum / 5;
		System.out.printf("국어 총점 : %d 국어 평균 : %f\n", ksum, kavg);
		System.out.printf("영어 총점 : %d 영어 평균 : %f\n", esum, eavg);
		System.out.printf("수학 총점 : %d 수학 평균 : %f\n", msum, mavg);
		
		
		
		
		
	}

}
