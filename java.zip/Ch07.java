import java.util.Scanner;

public class Ch07 {
	

	public static void main(String[] args) {
		// 00 분기문
		
		// 참조건문과 반복문 중간에서 코드블럭을 나눠서 처리하는 문법
		// 그 예로는 if문, switch문, for문, while문 등이 있다.
		
		// 01 if문
		// 조건문을 작성할 때 사용하는 구문
		// 조건식이 참이라면 코드 블럭을 실행
		// 조건식이 거짓이라면 코드 블럭을 무시 (스킵)
		
		
		// 조건식은 참 또는 거짓을 판단할 수 있는 식이여야만 한다.
		// 과 거짓
		
		// 02 if문의 형식
		
		// 2-1) if문
		// if ( 조건식 )  {
		//						//	
		//						// 조건식이 참이라면 이 실행코드 실행
		//						//
		// }
//	
//		if (true) {
//			System.out.println("조건식이 참이고 if문 진입");
//		}
//		System.out.println("if문 처리 이후 실행코드");
//		System.out.println();
//		
//		
//		
//		System.out.println("----------------------- if문 - 예제 01 ---------------------");
//		
//		Scanner sc = new Scanner(System.in);
//		int num = sc.nextInt();
//		
//		// 첫번째 if문 : 짝수 여부 체크
//		if (num % 2 == 0 ) {
//			System.out.println(num + "는 짝수입니다.");
//			System.out.println("첫번째 if문 끝");
//		}
//		
//		// 두번째 if문 : 홀수 여부 체크
//		if ( num % 2 == 1) {
//			System.out.println(num + "는 홀수입니다.");
//			System.out.println("두번째 if문 끝");
//		}
//		System.out.println();
//		

        
        // IF문 문제 01)
     // 사용자로부터 정수 하나를 입력받고 3의 배수이면 3의 배수입니다가 출력되도록 코딩하세요.
//		Scanner sc = new Scanner(System.in);
		
		
		
//		System.out.print("정수를 하나 입력해주세요 >>>");
//		
//		
//		int number = sc.nextInt();
//		
//		// 1. number라는 수가 3의 배수일 때		"3의 배수입니다."
//		if (number % 3 == 0) {
//			System.out.println("3의 배수입니다.");
//		}
//		// 2. number라는 수가 3의 배수가 아닐 때 "3의 배수가 아닙니다"
////		if (number % 3 != 0) {
////			System.out.println("3의 배수아닙니다..");
////			
////		}
//		// OR, 또는
//		
//		if (number % 3 == 1 || number % 3 == 2) {
//			System.out.println("3의 배수아닙니다.");
//		}
//		
		
		
		// 2-2) if문과 else문
		
//		if (조건식) {			
//								// 조건식이 참이라면 이 실행코드 실행
//		} 
//		
//		else {
//								// 조건식이 거짓이라면 이 실행코드 실행
//			
//		}
		

//	     IF-ELSE문 문제 01
	    // 사용자로부터 두 정수를 입력받는다.
	    // 두 수의 합이 짝수면 "두 수의 합은 짝수입니다."
	    // 두 수의 합이 홀수면 "두 수의 합은 홀수입니다" 
	    // 위와 같은 결과값이 나오도록 코딩하세요 !
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("두 정수를 입력해주세요 >>>");
//		int num = sc.nextInt();
//		int num2 = sc.nextInt();
//		int sum = num + num2;
//		
//		if (sum % 2 == 0) {
//			// 두수의 합이 짝수인 경우
//			System.out.println("두 수의 합은 짝수입니다.");
//		} else {
//			// 두수의 합이 짝수라는 조건식에 부합하지 않는 경우 == 두수의 합이 홀수
//			System.out.println("두 수의 합은 홀수입니다.");
//			
//		}
		
		
		
	       
	    // IF-ELSE문 문제 02
	    // 사용자로부터 정수를 입력받는다.
	    // 그 수가 num >= 2 && num <= 20 이면
	    // 조건식이 참이면 "2 ~ 20범위 안에 있습니다."
	    // 조건식이 거짓이며 "범위를 벗어났습니다."
	    // 위와 같은 결과값이 나오도록 코딩하세요 !
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("하나의 정수를 입력해주세요 >>>");
//		int num = sc.nextInt();
//		
//		if (num >=2 && num <= 20) {
//			System.out.println("2 ~ 20 범위 안에 있습니다.");
//		} else {
//			System.out.println("범위를 벗어났습니다.");
//		}
		
		
		// 2-3) 중첩 if문
//		if (조건식1 ) {
//						// 조건식1이 참인 경우 실행되는 코드 블럭
		
//			if(조건식2) {
//						// 조건식1과 조건식2가 모두 참인 경우 실행되는 코드 블럭
//			}
//		}
		
		// 2-4) 중첩 if문과 else문
		
//		if(조건식1) {
//								// 조건이 참인 경우 실행되는 코드 블럭
//			if(조건식2) {
//								// 조건식1과 조건식2가 모두 참인 경우 실행되는 코드 블럭
//			}
//		} else {					// 조건식1이 거짓인 경우 실행되는 코드 블럭
//		}
//			
		/*
		 * System.out.println("---------------- 중첩 if-else문 활용 예제 -----------------");
		 * // DB에 저장되어 있는 ID, PWD String id = "javaclass"; String pwd = "test1234";
		 * 
		 * 
		 * Scanner sc = new Scanner(System.in); // Client로 부터 입력받은 ID
		 * System.out.print("ID를 입력해주세요 >>>"); String input_id = sc.next();
		 * 
		 * // (equals() 메서드(함수)를 이용) // 기존의 DB에 저장되어 있i는 ID(javaclass)와 입력한
		 * ID(input_id)가 일치한지 비교 // 일치하다면 true를 반환 // 일치하지 않느다면 flase를 반환 if
		 * (input_id.equals(id)) { // 입력한 id == 저장된 id
		 * System.out.println("[SYSTEM] : ID가 일치합니다.");
		 * 
		 * System.out.print("PW를 입력해주세요 >>>"); String input_pw = sc.next();
		 * 
		 * // 기존의 DB에 저장되어 있는 PW(test1234)와 입력한 PW(input_pw)가 일치한지 비교 if
		 * (input_pw.equals(pwd)) { // ID는 일치하고 // 입력한 pw == 저장된 pw
		 * System.out.println("[SYSTEM] : PWD가 일치합니다.");
		 * System.out.println("[SYSTEM] : LOGIN SUCCESS !!!");
		 * System.out.println("[SYSTEM] : " + id + "님 환영합니다."); } else { // ID는 일치하지만 //
		 * 입력한 pw != 저장된 pw System.out.println("[SYSTEM] : PWD가 일치하지 않습니다.");
		 * System.out.println("[SYSTEM] : 프로그램을 종료합니다."); } } else { // 입력한 id != 저장된 id
		 * System.out.println("[SYSTEM] : ID가 일치하지 않습니다.");
		 * System.out.println("[SYSTEM] : 프로그램을 종료합니다."); }
		 */
		
//      If문 통합 문제 01)
     //	짝수이면서 3의 배수이면 출력
     //	홀수이면서 5의 배수이면 출력
//		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("하나의 정수를 입력해주세요 >>>");
//		int num = sc.nextInt();
//		
//		
//		if (num % 2 == 0) {
//			// 짝수
//			if(num % 3 == 0) {
//				System.out.println("짝수이면서 3의 배수입니다.");
//			}
//		} else {
//			// 홀수
//			if(num % 5 == 0) {
//				System.out.println("홀수이면서 5의 배수입니다.");
//			}
//		}
//		
//		// 또는, OR
//		
//		if (num % 2 == 0 && num % 3 == 0) {
//			System.out.println("짝수이면서 3의 배수입니다.");
//		} 
//		if (num % 2 == 1 && num % 5 == 0) {
//			System.out.println("홀수이면서 5의 배수입니다.");	
//		}
//		
//		
		
		
		// 05 else - if문
		// 다중분기
		System.out.println("-------------- else - if문 예제 01 ----------------");
		Scanner sc = new Scanner(System.in);
		System.out.print("나이 입력 : >>>");
		int age = sc.nextInt();
			
		if(age >= 20) {
			System.out.println("성인입니다.");
		} else if (age >= 8) {
			System.out.println("취학 아동입니다.");
		} else {
			System.out.println("미취학 아동입니다.");
		}
		
		
	    // else - if 문 문제 01)
	    //시험 점수를 입력받아 90 ~ 100점은 A,
		//80 ~ 89점은 B, 70 ~ 79점은 C,
		//60 ~ 69점은 D, 나머지 점수는 F를 출력하는 프로그램을 작성하시오.
		

		// score >= 90 A
		// score >= 80 B
		// score >= 70 C
		// score >= 60 D
		// 그외 F
		//or
		// score < 60 F
		// score < 70 D
		// score < 80 C
		// score < 90 B
		// 그외 A
		
//		Scanner sc = new Scanner(System.in); 
//		System.out.println("시험 점수를 입력해주세요 >>>");
//		int score = sc.nextInt();
//		
//		if(score >= 90) {
//			System.out.println("A");
//		} else if (score >= 80) {
//			System.out.println("B");
//		} else if (score >= 70) {
//			System.out.println("C");
//		} else if (score >= 60) {
//			System.out.println("D");
//		} else {
//			System.out.println("F");
//		}
		
		
		
		
	}

}
