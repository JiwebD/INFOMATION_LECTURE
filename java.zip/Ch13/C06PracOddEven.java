package Ch13;

// 프로그램은 sum 메소드를 통해 주어진 숫자들에 대한 홀수와 짝수의 합을 계산하고, 그 결과를 출력하는 간단한 프로그램입니다.

// sum 메소드를 호출하여 인수로 20, 21, 12, 111을 전달하고 반환값을 변수에 저장 후 결과를 출력

// [결과값]
// 짝수의 합 : 32
// 홀수의 합 : 132
// result = 164

public class C06PracOddEven {
	public int sum(int x, int y, int z, int w) {
		
		int evensum = 0;
		int oddsum  = 0;
		if(x % 2 == 0) {
			evensum += x;
		} else {
			oddsum += x;
		}
		
		if(y % 2 == 0) {
			evensum += y;
		} else {
			oddsum += y;
		}
		
		if(z % 2 == 0) {
			evensum += z;
		} else {
			oddsum += z;
		}
		
		
		if(w % 2 == 0) {
			evensum += w;
		} else {
			oddsum += w;
		}
		
		
		System.out.println("짝수의 합 : " + evensum);
		System.out.println("홀수의 합 : " + oddsum);
		
		return x + y + z + w;

	}
	
	
	public static void main(String[] args) {
		
		// 1. 문제 해결 시 '''작은 것'''부터 해결하면서 '추가'
		// 2. 내가 짠 코드 '''결과 예상'''하기
		// 3. 내가 '''컴파일러'''라고 생각하고 결과 예상하기
		
		
		C06PracOddEven obj = new C06PracOddEven();
		
		
		int result = obj.sum(20, 21, 12, 111);
		
		
		System.out.println("result = " + result);

	}
}
