package Ch13;

public class C05Account {
	// 속성(멤버 변수) 선언
	private String accountNumber;			// 계좌번호
	private double balance;					// 계좌잔액


	// 입금 메서드
	public void deposit(double amount) {
		// 받은 금액을 내 계좌잔액에 저장해주는 과정
		balance += amount;
		System.out.println("[SYSTEM] : 입금 완료. 현재 잔액 : $" + balance);
	}
	
	
	// 출금 메서드
	public void withdraw(double amount) {
		// 계좌잔액이 출금 잔액과 같거나 큰경우(더 많은 경우)
		if(balance >= amount ) {
			// 출금 처리
			balance -= amount;
			System.out.println("[SYSTEM] : 출금 완료. 현재 잔액 : $" + balance);
		} else {
			System.out.println("[SYSTEM] : " + (amount - balance) + "원 정도가 부족합니다.");		}
		
		
	}
	
	// 현재 계좌확인 메서드를 하나 만들기
	
	
	
	// Getter and Setter
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

}
