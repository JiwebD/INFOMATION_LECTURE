package Ch13;

public class C03AccessModifier {
	
	// private 접근 제어자
	
	private int privateField;
	
	// 메서드
	private void privateMethod() {
		System.out.println("This is PrivateMethod");
		
	}
	
	// ### Getter and Setter ###
	// 객체 지향 프로그래밍에서 클래스의 속성(멤버 변수)에 접근하거나 값을 설정하기 위한 메서드
	
	// Getter() 메서드 ( == 접근자 메서드)
	// Getter : private 속성 값 """ 읽기 """
	// 		  : 대개, private속성 이름 앞에 ''get''이라는 키워드를 붙여 메서드 이름을 지정 == get속성이름()
	public int getPrivateField() {
		return privateField;
	}
	
	// Setter() 메서드 ( == 설정자 메서드)
	// Setter : private 속성 값 """ 설정 """
	// 		  : 대개, private속성 이름 앞에 ''set''이라는 키워드를 붙여 메서드 이름을 지정 == set속성이름()
	public void setPrivateField(int privateField) {
		this.privateField = privateField;
	}
	// ### ''' this ''' Keyword ###
	// 클래스 내에서 사용되는 예약어
	// 생성되는 객체의 위치정보를 가져오는데 사용됨.
	
	// 멤버변수 vs 매개변수 구별
	// this.name = name
	
	
	public static void main(String[] args) {
		
		// C03AccessModifier의 인스턴스 생성
		C03AccessModifier obj = new C03AccessModifier();
		
		// private 접근제어자로 지정된 ( 변수 값 설정 + 메서드 호출 ==> 가능 )
		// Why? : 같은 클래스이기 때문임.
		obj.privateField = 123;
		obj.privateMethod();
		
		
		
		
		
	}
	

}
