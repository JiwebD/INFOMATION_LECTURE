package Ch13;

public class C05AccountMain {
	public static void main(String[] args) {
		
		C05Account donghaAcc = new C05Account();		
				
		
		donghaAcc.setAccountNumber("1111-9999-1234");
		donghaAcc.setBalance(10000);
		System.out.println("현재 잔액 : $" + donghaAcc.getBalance());
		
		donghaAcc.withdraw(3000.0);
		
		donghaAcc.deposit(20000.0);
		
		donghaAcc.withdraw(30000.0);
		
		
		
	}

}
