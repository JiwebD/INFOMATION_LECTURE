package Ch13;



// 문제 2: 컴퓨터 클래스 만들기

// 1. Computer 클래스를 완성하세요
// 2. 속성 : 이름, 시리얼넘버, CPU, RAM, DISK

// 3. 기능 : PowerOn() : Ex) MacOs 1010의 전원을 켭니다.

//		    PowerOff() : Ex) 갤럭시북5 2001의 전원을 끕니다.

//			ShowInfo() : Ex) 제품명 : MacOs
//							 시리얼넘버 : 1010
//							 CPUSpec : M1
//							 RAMSpec : 16GB
//							 DISKSpec : 1TB
// 4. Main메서드 완성하기
//		4-1) 컴퓨터 클래스의 객체 만들기
//		4-2) 객체 초기화
//		4-3) 전원 켜기
// 		4-4) 정보 출력하기
// 		4-5) 전원 끄기
class Computer {
	String name;
	int SerialNo;
	String CPUSpec;
	String RAMSpec;
	String DISKSpec;
	
	
	public Computer(String name, int SerialNo, String CPUSpec, String RAMSpec, String DISKSpec) {
		this.name = name;
		this.SerialNo = SerialNo;
		this.CPUSpec = CPUSpec;
		this.RAMSpec = RAMSpec;
		this.DISKSpec = DISKSpec;
	}
	
	public void PowerOn() {
		System.out.println(name + " " + SerialNo + "의 전원을 켭니다.");
		
	}
	public void PowerOff() {
		System.out.println(name + " " + SerialNo + "의 전원을 끕니다.");
	}
	
	public void ShowInfo() {
		System.out.println("[SYSTEM] : " + name + " 제품의 정보를 출력");
		System.out.println("-----------------------------------------------");
		System.out.println("제품명 : " + name);
		System.out.println("시리얼넘버 : " + SerialNo);
		System.out.println("CPUSpec : " + CPUSpec);
		System.out.println("RAMSpec : " + RAMSpec);
		System.out.println("DISKSpec : " + DISKSpec);
		System.out.println("-----------------------------------------------");
		
	}
	
}
public class C05PracComputerMain {
	public static void main(String[] args) {
		Computer m1mac = new Computer("MacOs", 1010, "M1", "16GB", "1TB");
//		M1Mac.name = "MacOs";
//		M1Mac.CPUSpec = "M1";
		
		m1mac.PowerOn();
		m1mac.ShowInfo();
		m1mac.PowerOff();
	}

	
	
	
	
}
