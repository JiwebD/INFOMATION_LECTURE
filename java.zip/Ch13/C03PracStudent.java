package Ch13;

//문제 2: 학생 클래스 만들기

//1. Student 클래스를 작성하세요.
//2. name과 age라는 두 개의 속성을 가지도록 클래스를 구성하세요.
//3. main에서 name과 age의 정보를 초기화(설정)해주세요
//4. displayInfo() 메소드를 구현하여 학생의 정보를 출력하세요.

public class C03PracStudent {
	// 속성(정보)
	String name;
	int age;
	
	// 메서드의 구조
	// 접근제어자 반환자료형 메서드명 (매개변수)
	public void displayInfo() {
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		
	}
	
	public static void main(String[] args) {
		int age = 2;
		System.out.println("나이 : "+ age);
		
		C03PracStudent mystudent = new C03PracStudent();
		mystudent.name = "홍길동";
		mystudent.age = 20;
		mystudent.displayInfo();
		// 이름: 홍길동
		// 나이: 20
	}
	
	

}
