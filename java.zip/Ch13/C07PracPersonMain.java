package Ch13;

class C07Person {
	String name;
	int age;
	String address;
	public void setPerson(String name) {
		this.name = name;
	}
	public void setPerson(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public void setPerson(String name, int age, String address) {
		this.name = name;
		this.age = age;
		this.address = address;
	}
	
	public void ShowInfo() {
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("주소 : " + address);
		
		
	}
	
	
	
}

public class C07PracPersonMain {
	
	public static void main(String[] args) {

		C07Person obj = new C07Person();
		obj.setPerson("홍길동"); //멤버변수 name에 "홍길동" 저장 
		obj.ShowInfo();			// 이름 : 홍길동
								// 나이 : 0
								// 주소 : null
		
		obj.setPerson("서길동", 10); //멤버변수 name, age에 각각 저장
		obj.ShowInfo();
		
		obj.setPerson("강호동", 55, "서울"); //멤버변수 name, age, addr에 각각 저장
		obj.ShowInfo();
	}

}
