package Ch13;

public class C01Person {
	// 속성
	String name;
	int age;
	String address;
	
	// 기능(함수, 메서드)
	void hello() {
		System.out.println(name + "이/가 인사합니다.");
	}
}

