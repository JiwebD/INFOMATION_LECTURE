package Ch14;
// ### this() ###
// OverLoading(오버로딩)된 다른 생성자 호출 가능

class C01Simple {
	int x;
	int y;
	
	public C01Simple() {
//		x = 10;
//		y = 20;
		
		this(10, 20);
		System.out.println("Default Constructor END");
	}
	
	public C01Simple(int x) {
//		this.x = x;
//		y = 20;
		this(x, 20);
		System.out.println("Parameter(int x) Constructor END");
	}
	
	public C01Simple(int x, int y) {
		System.out.println("Parameter(int x, int y) Constructor START");
		this.x = x;
		this.y = y;
		System.out.println("Parameter(int x, int y) Constructor END");
	}
}
public class C01This {
	public static void main(String[] args) {
		C01Simple obj = new C01Simple();
		C01Simple obj1 = new C01Simple(10);
		C01Simple obj2 = new C01Simple(10, 20);
	}

}
