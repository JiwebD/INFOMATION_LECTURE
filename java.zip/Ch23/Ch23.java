package Ch23;

//### OutputStream 및 InputStream ###
//
//OutputStream 및 InputStream은 바이트 단위로 데이터를 처리
//이는 주로 이미지, 동영상, 사운드 파일 등 이진 데이터를 다룰 때 사용
//이진 데이터의 경우에는 바이트 스트림을 사용하여 효율적으로 읽고 쓸 수 있음.
//
//### Writer 및 Reader ###
//
//Writer 및 Reader는 문자 단위로 데이터를 처리
//이는 주로 텍스트 파일을 다룰 때 사용
//문자 데이터의 경우 텍스트를 읽거나 쓸 때 인코딩을 고려해야 하며, 문자 스트림을 사용하여 문자 데이터를 더 효과적으로 처리할 수 있음.




public class Ch23 {

}
