import java.util.Scanner;

public class Ch08 {
	public static void main(String[] args) {
		// 00 switch문 (다중 분기)
		// 조건문 중 하나
		// 조건이 여러개일 떄 각 조건에 따른 코드를 실행할 수 있음.
		
		// 01 switch문 구조
		

		//switch (변수) {
		//case 값1:					// case는 여러개일 수 있다.
//									// case == if문이면서 else if문이기도 함.
//			실행할 코드1;
//			break;					// 위 코드를 실행 후 break;를 만나면 Stop역할
		// 
		//case 값2:					// 얘는 else if니깐 :)
//			실행할 코드2;
//			break;
		// 
		//default:					// else문(case의 조건에 부합하지 않을 시 나머지 처리)
//			break;
		//}
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("한개의 정수를 입력해주세요 >>>");
//		int num = sc.nextInt();
//		
//		switch (num)  {
//		case 1:	
//			System.out.println("[SYSTEM] : num == 1");
//			break;
//		case 2:
//			System.out.println("[SYSTEM] : num == 2");
//			break;
//		case 3:
//			System.out.println("[SYSTEM] : num == 3");
//			break;
//		default:
//			System.out.println("[SYSTEM] : num != 1, 2, 3");
//			break;
//		}
		
		
	}
}
